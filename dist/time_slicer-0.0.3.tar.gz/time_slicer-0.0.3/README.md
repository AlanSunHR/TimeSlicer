# TimeSlicer
A simple package to slice time into intervals, so that code snippets can be executed in a fixed frequency, which might be useful for real-time robot control(but you should not expect to control in semi-millisecond level).
